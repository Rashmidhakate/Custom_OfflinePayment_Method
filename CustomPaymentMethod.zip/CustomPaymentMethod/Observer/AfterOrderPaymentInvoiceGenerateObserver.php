<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * OfflinePayments Observer
 */
namespace CP\CustomPaymentMethod\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class AfterOrderPaymentInvoiceGenerateObserver implements ObserverInterface
{
   
    protected $_invoiceService;
    protected $_transactionFactory;

    public function __construct(
      \CP\CustomPaymentMethod\Helper\Data $helper,
      \Magento\Framework\DB\TransactionFactory $transactionFactory
    ) {
       $this->helper = $helper;
       $this->_transactionFactory = $transactionFactory;
    }

      /**
     *
     * @param Observer $observer
     * @return $this
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        if(!$order->getId()) {
            return $this;
        }

        $invoice = $this->helper->createInvoice($order);
        if($invoice) {
            $this->helper->createShipment($order, $invoice);
        }

        return $this;
    }
}
