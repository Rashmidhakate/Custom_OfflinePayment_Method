<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\CustomPaymentMethod\Block\Form;

/**
 * Block for Cash On Delivery payment method form
 */
class Invoice30 extends \Magento\OfflinePayments\Block\Form\AbstractInstruction
{
    /**
     * Cash on delivery template
     *
     * @var string
     */
    protected $_template = 'form/invoice30.phtml';
}
